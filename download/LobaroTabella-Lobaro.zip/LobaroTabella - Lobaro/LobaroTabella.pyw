# -*- coding: utf-8 -*-
"""
LobaroTabella - finestra (stile BedoMaxContab) per trasformare il CSV export
della piattaforma Lobaro in una tabella Excel: matricole, date di scarico,
lettura di ogni mese, dati del telegramma.

Tre file portatili: LobaroTabella.pyw (questa finestra), LobaroTabella.py
(il motore, usabile anche da riga di comando), "Avvia Lobaro tabella.bat".
Solo libreria standard di Python 3. Trascinando uno o piu' CSV sul .bat i
file risultano gia' scelti.
"""
import os, sys, json, shutil, subprocess, threading, traceback
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)
import LobaroTabella as motore
T = motore.T

PROGRAMMA = "BedoMaxContab"
COPYRIGHT = "(c) 2026 BedoMaxContab - tutti i diritti riservati"
BLU, BLU_SC, GRIGIO = "#1a5276", "#154360", "#f4f6f7"
OCRA, OCRA_SC = "#7d6608", "#5f4d06"
IMPOSTAZIONI = os.path.join(APP_DIR, "impostazioni.cfg")     # testo JSON, estensione anonima
_IMPOSTAZIONI_VECCHIE = os.path.join(APP_DIR, "impostazioni.json")


def impostazioni_leggi():
    """{cartella_csv, cartella_archivio}: dove PRENDERE i CSV esportati dalla
    piattaforma e dove ARCHIVIARE tutto (Excel, PDF e copia dei CSV)."""
    for p in (IMPOSTAZIONI, _IMPOSTAZIONI_VECCHIE):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict): return d
        except Exception:
            pass
    return {}


def impostazioni_salva(d):
    with open(IMPOSTAZIONI, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)


def impostazioni_valide(d):
    return bool(d.get("cartella_csv")) and bool(d.get("cartella_archivio")) \
        and os.path.isdir(d["cartella_csv"]) and os.path.isdir(d["cartella_archivio"])


def _log_errore(dove):
    try:
        with open(os.path.join(APP_DIR, "errori.txt"), "a", encoding="utf-8") as f:
            f.write("%s  %s\n%s\n" % (datetime.now().strftime("%d/%m/%Y %H:%M:%S"), dove,
                                      traceback.format_exc()))
    except Exception:
        pass


def _apri(path):
    try:
        os.startfile(path)
    except Exception:
        subprocess.Popen(["xdg-open", path])


class App(tk.Tk):
    def __init__(self, files):
        super().__init__()
        self.title("%s - Tabella letture Lobaro (%s)" % (PROGRAMMA, motore.DITTA))
        self.configure(bg=GRIGIO)
        self.minsize(980, 600)
        self.files = list(files)
        self.out = None
        self._attesa = None
        self.cfg = impostazioni_leggi()
        _l = self.cfg.get("lingua", motore.lingue_edizione()[0])
        motore.imposta_lingua(_l if _l in motore.lingue_edizione() else motore.lingue_edizione()[0])
        self._riavvia = False
        self.title("%s - %s (%s)" % (PROGRAMMA, T("Tabella letture Lobaro (finestra)"), motore.DITTA))
        self._build()
        self._mostra_file()
        self._mostra_cartelle()
        self.after(200, self._centra)
        # PRIMO AVVIO (o cartelle sparite): si chiede subito dove prendere e
        # dove archiviare; la finestra resta correggibile col pulsante "Cartelle"
        if not impostazioni_valide(self.cfg):
            self.after(400, lambda: self.cartelle(prima_volta=True))

    # ------------------------------------------------------------ finestra
    def _build(self):
        head = tk.Frame(self, bg="white"); head.pack(fill="x")
        self._logo = None
        for nome in (motore.LOGO_PNG,):
            p = os.path.join(APP_DIR, nome)
            if os.path.exists(p):
                try:
                    img = tk.PhotoImage(file=p)
                    f = max(-(-img.height() // 56), -(-img.width() // 420), 1)
                    self._logo = img.subsample(f, f) if f > 1 else img
                    break
                except Exception:
                    self._logo = None
        if self._logo:
            tk.Label(head, image=self._logo, bg="white", bd=0).pack(side="left", padx=16, pady=6)
        else:
            tk.Label(head, text=PROGRAMMA, fg=BLU, bg="white",
                     font=("Segoe UI", 20, "bold")).pack(side="left", padx=16, pady=10)
        tk.Button(head, text=T("?  Guida"), command=self.guida, bg=BLU, fg="white",
                  activebackground=BLU_SC, activeforeground="white", relief="flat",
                  font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="right", padx=(0, 16))
        tk.Button(head, text=T("Cartelle"), command=self.cartelle, bg=OCRA, fg="white",
                  activebackground=OCRA_SC, activeforeground="white", relief="flat",
                  font=("Segoe UI", 10, "bold"), padx=12, pady=4).pack(side="right", padx=(0, 8))
        # tendina LINGUA (italiano / inglese / tedesco): cambia testi della
        # finestra, dell'Excel e del PDF; la scelta resta in impostazioni.json
        lingue = motore.lingue_edizione()
        self.lingua_var = tk.StringVar(value=motore.LINGUE.get(motore.LINGUA, "Italiano"))
        if len(lingue) > 1:                      # edizione multilingue: tendina
            fr_l = tk.Frame(head, bg="white"); fr_l.pack(side="right", padx=(0, 10))
            tk.Label(fr_l, text=T("Lingua") + ":", bg="white", fg=BLU, font=("Segoe UI", 9)).pack(side="left")
            cb = ttk.Combobox(fr_l, textvariable=self.lingua_var, state="readonly", width=9,
                              values=[motore.LINGUE[l] for l in lingue])
            cb.pack(side="left", padx=4); cb.bind("<<ComboboxSelected>>", self.cambia_lingua)
        tk.Label(head, text="%s  -  %s" % (motore.DITTA, T("Tabella letture Lobaro (finestra)")), fg=BLU, bg="white",
                 font=("Segoe UI", 12, "italic")).pack(side="right", padx=16)
        tk.Frame(self, bg=BLU, height=3).pack(fill="x")

        # ---- pulsanti raggruppati come nell'app principale
        def _gruppo(parent, titolo, bg, fg):
            fr = tk.Frame(parent, bg=bg, highlightbackground=fg, highlightthickness=1)
            fr.pack(side="left", padx=(0, 12), pady=2)
            tk.Label(fr, text=titolo, bg=bg, fg=fg, justify="left",
                     font=("Segoe UI", 8, "bold")).pack(side="left", padx=(8, 4))
            return fr

        def _btn(fr, testo, cmd, **kw):
            b = tk.Button(fr, text=testo, command=cmd, bg="white", activebackground=GRIGIO,
                          relief="groove", bd=1, font=("Segoe UI", 9), **kw)
            b.pack(side="left", padx=3, pady=4)
            return b

        # due righe di gruppi (come nell'app principale): cosi' le scritte dei
        # pulsanti restano intere anche su schermi stretti
        cmd = tk.Frame(self, bg=GRIGIO); cmd.pack(fill="x", padx=12, pady=(8, 0))
        if motore.LEGGE_REP:
            g1 = _gruppo(cmd, T("FILE DA ELABORARE\nCSV Lobaro o .rep WTT16"), "#d6eaf8", BLU)
            _btn(g1, T("1. Scegli i file (CSV Lobaro / .rep WTT16)..."), self.scegli, padx=10)
        else:
            g1 = _gruppo(cmd, T("FILE DA ELABORARE\nCSV Lobaro"), "#d6eaf8", BLU)
            _btn(g1, T("1. Scegli i file (CSV Lobaro)..."), self.scegli, padx=10)
        _btn(g1, T("Togli dall'elenco"), self.togli, padx=10)
        cmd2 = tk.Frame(self, bg=GRIGIO); cmd2.pack(fill="x", padx=12)
        g2 = _gruppo(cmd2, T("TABELLA\nExcel + PDF"), "#d5f5e3", "#1e8449")
        self.b_crea = _btn(g2, T("2. Crea tabella Excel + PDF"), self.crea, padx=10)
        self.b_apri = _btn(g2, T("3. Apri l'Excel"), self.apri_excel, state="disabled", padx=10)
        self.b_pdf = _btn(g2, T("4. Apri il PDF (stampa)"), self.apri_pdf, state="disabled", padx=10)
        _btn(g2, T("Apri la cartella archivio"), self.apri_cartella, padx=10)

        # ---- cartelle in uso (prendo da / archivio)
        fr_c = tk.Frame(self, bg="#fdf6e3"); fr_c.pack(fill="x", padx=12, pady=(6, 0))
        self.lbl_cart = tk.Label(fr_c, text="", bg="#fdf6e3", fg=OCRA, anchor="w", justify="left",
                                 font=("Segoe UI", 8), padx=6, pady=2)
        self.lbl_cart.pack(side="left", fill="x", expand=True)
        tk.Button(fr_c, text=T("cambia..."), command=self.cartelle, bg="#fdf6e3", fg=OCRA, relief="flat",
                  font=("Segoe UI", 8, "underline"), cursor="hand2").pack(side="right", padx=6)

        # ---- file scelti
        fr_f = tk.Frame(self, bg=GRIGIO); fr_f.pack(fill="x", padx=12, pady=(6, 0))
        tk.Label(fr_f, text=T("File scelti:"), bg=GRIGIO, font=("Segoe UI", 9, "bold")).pack(side="left")
        self.lbl_file = tk.Label(fr_f, text="", bg=GRIGIO, fg="#566573", anchor="w",
                                 justify="left", font=("Segoe UI", 9))
        self.lbl_file.pack(side="left", padx=6, fill="x", expand=True)

        # ---- anteprima della tabella (foglio "Letture mensili")
        corpo = tk.Frame(self, bg=GRIGIO); corpo.pack(fill="both", expand=True, padx=12, pady=8)
        tk.Label(corpo, text=T("ANTEPRIMA - Letture mensili (una riga per matricola; nell'Excel ci sono anche "
                 "Consumi mensili, Valori memorizzati e Telegrammi)"), bg="#6c3483", fg="white",
                 anchor="w", padx=8, pady=3, font=("Segoe UI", 9, "bold")).pack(fill="x")
        fr_t = tk.Frame(corpo); fr_t.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(fr_t, show="headings")
        sy = ttk.Scrollbar(fr_t, orient="vertical", command=self.tree.yview)
        sx = ttk.Scrollbar(fr_t, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        sy.pack(side="right", fill="y"); sx.pack(side="bottom", fill="x")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.tag_configure("vuota", foreground="#a93226")
        self.tree.tag_configure("piatt", foreground="#7d6608")
        self.tree.tag_configure("batt", background="#fdebd0")
        self.tree.bind("<Double-1>", lambda e: self.apri_excel() if self.out else None)

        # ---- riepilogo + barra di stato + diritti
        self.riass = tk.Label(self, text="", bg=GRIGIO, fg=BLU, anchor="w", justify="left",
                              font=("Segoe UI", 9)); self.riass.pack(fill="x", padx=12)
        piede = tk.Frame(self, bg="white"); piede.pack(fill="x", side="bottom")
        self.stato = tk.Label(piede, text=T("Pronto. Scegli il CSV esportato dalla piattaforma Lobaro."),
                              bg="white", fg="#1c2833", anchor="w", font=("Segoe UI", 9))
        self.stato.pack(side="left", fill="x", expand=True, padx=12, pady=4)
        tk.Label(piede, text=COPYRIGHT, bg="white", fg="#85929e",
                 font=("Segoe UI", 8)).pack(side="right", padx=12)
        # firma del produttore: logo BMC in piccolo + "by BedoMaxContab"
        self._logo_bmc = None
        try:
            pb = os.path.join(APP_DIR, "logo_bmc_piccolo.png")
            if os.path.exists(pb): self._logo_bmc = tk.PhotoImage(file=pb)
        except Exception:
            self._logo_bmc = None
        tk.Label(piede, text=motore.FIRMA, bg="white", fg="#5d6d7e", font=("Segoe UI", 8, "italic")).pack(side="right")
        if self._logo_bmc:
            tk.Label(piede, image=self._logo_bmc, bg="white", bd=0).pack(side="right", padx=(0, 4))

    def _centra(self):
        try:
            self.update_idletasks()
            w, h = max(self.winfo_width(), 1000), max(self.winfo_height(), 600)
            x = (self.winfo_screenwidth() - w) // 2; y = (self.winfo_screenheight() - h) // 3
            self.geometry("%dx%d+%d+%d" % (w, h, max(0, x), max(0, y)))
        except Exception:
            pass

    # -------------------------------------------------------- barra attesa
    def _attesa_avvia(self, testo):
        """Barra animata + secondi nella barra di stato (regola GUI BedoMaxContab)."""
        t0 = datetime.now(); stop = {"v": False}
        def giro(k=0):
            if stop["v"]: return
            s = int((datetime.now() - t0).total_seconds())
            self.stato.config(text="%s  %s  %d s" % (testo, "|/-\\"[k % 4], s), fg="#b9770e")
            self.after(250, giro, k + 1)
        giro()
        def ferma():
            stop["v"] = True
        return ferma

    # ------------------------------------------------------------ cartelle
    def _mostra_cartelle(self):
        c = self.cfg
        if impostazioni_valide(c):
            self.lbl_cart.config(text="%s  %s      %s  %s"
                                 % (T("PRENDO I CSV DA:"), c["cartella_csv"],
                                    T("ARCHIVIO (Excel, PDF, copia dei CSV):"), c["cartella_archivio"]))
        else:
            self.lbl_cart.config(text=T("Cartelle NON impostate: premi 'Cartelle' per dire dove prendere i CSV "
                                        "e dove archiviare il materiale."))

    def cartelle(self, prima_volta=False):
        """Finestra delle cartelle: dove prendere i CSV e dove archiviare.
        Si apre da sola al primo avvio; sempre correggibile dal pulsante."""
        try:
            win = tk.Toplevel(self); win.title(T("CARTELLE DI LAVORO")); win.transient(self); win.grab_set()
            win.configure(bg=GRIGIO); win.resizable(False, False)
            tk.Label(win, text=T("CARTELLE DI LAVORO"), bg=OCRA, fg="white", anchor="w", padx=10, pady=5,
                     font=("Segoe UI", 10, "bold")).pack(fill="x")
            intro = T("Dimmi dove PRENDERE i CSV esportati dalla piattaforma Lobaro e dove ARCHIVIARE\n"
                      "tutto il materiale (tabelle Excel, PDF di stampa e una copia dei CSV elaborati).\n"
                      "Le due cartelle possono anche coincidere. Si cambiano quando vuoi, da qui.")
            if prima_volta:
                intro = T("PRIMO AVVIO: ") + intro
            tk.Label(win, text=intro, bg=GRIGIO, justify="left", font=("Segoe UI", 9), padx=12, pady=8).pack(anchor="w")
            v1 = tk.StringVar(value=self.cfg.get("cartella_csv", ""))
            v2 = tk.StringVar(value=self.cfg.get("cartella_archivio", ""))
            def riga(testo, var):
                fr = tk.Frame(win, bg=GRIGIO); fr.pack(fill="x", padx=12, pady=3)
                tk.Label(fr, text=testo, bg=GRIGIO, width=34, anchor="w", font=("Segoe UI", 9, "bold")).pack(side="left")
                tk.Entry(fr, textvariable=var, width=62, font=("Segoe UI", 9)).pack(side="left", padx=4)
                def sfoglia():
                    d = filedialog.askdirectory(parent=win, title=testo, initialdir=var.get() or os.path.expanduser("~"))
                    if d: var.set(os.path.normpath(d))
                tk.Button(fr, text=T("Sfoglia..."), command=sfoglia, relief="groove", bd=1).pack(side="left")
            riga(T("Prendo i CSV da (cartella dei download):"), v1)
            riga(T("Archivio del materiale (Excel, PDF, CSV):"), v2)
            tk.Label(win, text=T("Consiglio: l'archivio su una cartella di rete condivisa, cosi' lo vedono tutti."),
                     bg=GRIGIO, fg="#566573", font=("Segoe UI", 8), padx=12).pack(anchor="w")
            def salva():
                c1, c2 = v1.get().strip(), v2.get().strip()
                if not c1 or not c2:
                    messagebox.showwarning(T("Cartelle"), T("Compila tutte e due le cartelle."), parent=win); return
                for c in (c1, c2):
                    if not os.path.isdir(c):
                        if messagebox.askyesno(T("Cartelle"), T("La cartella non esiste:\n%s\n\nLa creo?\n\n(INVIO = Si'   -   ESC = No)") % c, parent=win):
                            try: os.makedirs(c, exist_ok=True)
                            except Exception as e:
                                messagebox.showerror(T("Cartelle"), T("Non riesco a crearla: %s") % e, parent=win); return
                        else:
                            return
                self.cfg = {"cartella_csv": c1, "cartella_archivio": c2, "lingua": motore.LINGUA}
                try:
                    impostazioni_salva(self.cfg)
                except Exception as e:
                    messagebox.showerror(T("Cartelle"), T("Non riesco a salvare impostazioni.cfg: %s") % e, parent=win); return
                self._mostra_cartelle(); win.destroy()
                self.stato.config(text=T("Cartelle salvate. Ora '1. Scegli i file...'"), fg="#1e8449")
            fr_b = tk.Frame(win, bg=GRIGIO); fr_b.pack(pady=10)
            tk.Button(fr_b, text=T("Salva"), command=salva, bg=BLU, fg="white", relief="flat", padx=16, pady=4,
                      font=("Segoe UI", 9, "bold")).pack(side="left", padx=6)
            tk.Button(fr_b, text=T("Annulla"), command=win.destroy, relief="groove", bd=1, padx=12, pady=4).pack(side="left", padx=6)
            win.bind("<Return>", lambda e: salva()); win.bind("<Escape>", lambda e: win.destroy())
            self.update_idletasks()
            win.geometry("+%d+%d" % (self.winfo_rootx() + 60, self.winfo_rooty() + 90))
        except Exception:
            _log_errore("finestra cartelle")

    # -------------------------------------------------------------- azioni
    def _mostra_file(self):
        if not self.files:
            self.lbl_file.config(text=T("(nessuno)"))
        else:
            nomi = [os.path.basename(f) for f in self.files]
            testo = ", ".join(nomi[:4]) + ("  e altri %d" % (len(nomi) - 4) if len(nomi) > 4 else "")
            self.lbl_file.config(text=testo)

    def scegli(self):
        d = self.cfg.get("cartella_csv") if impostazioni_valide(self.cfg) else \
            (os.path.dirname(self.files[0]) if self.files else os.path.expanduser("~"))
        sel = filedialog.askopenfilenames(parent=self, title=T("Scegli il CSV Lobaro o il file .rep/.BIL del gateway WTT16") if motore.LEGGE_REP
                                          else T("Scegli il CSV esportato dalla piattaforma Lobaro"),
                                          initialdir=d, filetypes=motore.filtro_file())
        for f in sel:
            if f not in self.files: self.files.append(f)
        self._mostra_file()
        if sel:
            self.stato.config(text=T("%d file scelti. Premi '2. Crea tabella Excel + PDF'.") % len(self.files), fg="#1c2833")

    def togli(self):
        self.files = []; self._mostra_file()
        self.stato.config(text=T("Elenco file svuotato."), fg="#1c2833")

    def crea(self):
        if not self.files:
            messagebox.showwarning(T("Tabella"), T("Prima scegli almeno un CSV (pulsante 1)."), parent=self); return
        if not impostazioni_valide(self.cfg):
            messagebox.showwarning(T("Tabella"), T("Prima imposta le cartelle (pulsante 'Cartelle' in alto)."), parent=self)
            self.cartelle(); return
        arch = self.cfg["cartella_archivio"]
        nome = os.path.splitext(os.path.basename(self.files[0]))[0]
        base = os.path.join(arch, nome + " - tabella.xlsx")
        if os.path.exists(base):
            if not messagebox.askyesno(T("Tabella"), T("Esiste gia':\n%s\n\nLo sovrascrivo?\n\n(INVIO = Si'   -   ESC = No)")
                                       % base, parent=self):
                return
        self.b_crea.config(state="disabled"); self.b_apri.config(state="disabled"); self.b_pdf.config(state="disabled")
        ferma = self._attesa_avvia(T("Leggo i telegrammi e preparo la tabella..."))
        esito = {}
        def lavoro():
            try:
                out, riass, righe, mesi = motore.crea_tabella(self.files, base)
                # copia dei CSV elaborati nell'archivio (sottocartella "CSV originali")
                copiati = 0
                d_csv = os.path.join(arch, "File originali")
                for f in self.files:
                    try:
                        if os.path.normcase(os.path.dirname(os.path.abspath(f))) == os.path.normcase(os.path.abspath(d_csv)):
                            continue
                        os.makedirs(d_csv, exist_ok=True)
                        dest = os.path.join(d_csv, os.path.basename(f))
                        if not os.path.exists(dest) or os.path.getsize(dest) != os.path.getsize(f):
                            shutil.copy2(f, dest); copiati += 1
                    except Exception:
                        _log_errore("copia csv in archivio")
                esito.update(out=out, riass=riass, righe=righe, mesi=mesi, copiati=copiati)
            except Exception as e:
                esito["err"] = str(e); _log_errore("crea tabella")
            self.after(0, fine)
        def fine():
            ferma(); self.b_crea.config(state="normal")
            if "err" in esito:
                self.stato.config(text=T("ERRORE: %s") % esito["err"], fg="#a93226")
                messagebox.showerror(T("Tabella"), esito["err"] + "\n\n" + T("(dettagli in errori.txt)"), parent=self)
                return
            try:
                self.out = esito["out"]; self.b_apri.config(state="normal")
                self.out_pdf = os.path.splitext(self.out)[0] + ".pdf"
                if os.path.exists(self.out_pdf): self.b_pdf.config(state="normal")
                self._anteprima(esito["righe"], esito["mesi"])
                self.riass.config(text=esito["riass"].split("\n", 1)[1])
                self.stato.config(text=T("Creati in archivio Excel e PDF: %s%s   (3 = Excel, 4 = PDF da stampare)")
                                  % (os.path.basename(self.out),
                                     T(", file copiati: %d") % esito["copiati"] if esito.get("copiati") else ""), fg="#1e8449")
            except Exception:
                _log_errore("anteprima")
                self.stato.config(text=T("Excel creato, anteprima non riuscita (vedi errori.txt)"), fg="#a93226")
        threading.Thread(target=lavoro, daemon=True).start()

    def _anteprima(self, righe, mesi):
        t = self.tree
        t.delete(*t.get_children())
        cols = ["Matricola", "Tipo", "Costruttore", "Ultimo scarico", "Ultima lettura", "Unita'",
                "Valore al set-day", "Data set-day", "RSSI ultimo", "N. telegrammi", "Fonte", "Batteria", "Errore (cod.)", "Significato errore"] + \
               [motore.etichetta_mese(m) for m in mesi]
        t["columns"] = cols
        larg = {"Matricola": 80, "Tipo": 80, "Costruttore": 70, "Ultimo scarico": 110, "Ultima lettura": 90,
                "Unita'": 50, "Valore al set-day": 100, "Data set-day": 85, "RSSI ultimo": 60,
                "N. telegrammi": 70, "Fonte": 90, "Batteria": 60, "Errore (cod.)": 60, "Significato errore": 170}
        for c in cols:
            t.heading(c, text=T(c)); t.column(c, width=larg.get(c, 75), anchor="center", stretch=False)
        def fmt(v):
            if v is None: return ""
            if isinstance(v, datetime): return v.strftime("%d/%m/%Y %H:%M" if v.hour or v.minute else "%d/%m/%Y")
            if isinstance(v, float): return ("%.3f" % v).rstrip("0").rstrip(".") if v != int(v) else str(int(v))
            return str(v)
        for r in righe:
            vals = [fmt(motore._tr(r[c])) for c in cols[:14]] + [fmt(r["_letture"].get(m)) for m in mesi]
            tag = "vuota" if r["Ultima lettura"] is None else ("piatt" if r["Fonte"] == "piattaforma" else ("batt" if r.get("Batteria") == "scarica" else ""))
            t.insert("", "end", values=vals, tags=(tag,))

    def apri_excel(self):
        if self.out and os.path.exists(self.out): _apri(self.out)

    def apri_pdf(self):
        p = getattr(self, "out_pdf", None)
        if p and os.path.exists(p): _apri(p)

    def apri_cartella(self):
        d = os.path.dirname(self.out) if self.out else self.cfg.get("cartella_archivio") or APP_DIR
        _apri(d)

    def guida(self):
        # prima scelta: la guida PDF col logo (GUIDA LobaroTabella.pdf); in
        # mancanza, il testo del LEGGIMI in una finestrella
        g = motore.EDIZIONE.get("guide", {})
        nomi = [g.get(motore.LINGUA), g.get("it"), "GUIDA LobaroTabella.pdf"]
        for nome in [n for n in nomi if n]:
            p_pdf = os.path.join(APP_DIR, nome)
            if os.path.exists(p_pdf):
                _apri(p_pdf); return
        win = tk.Toplevel(self); win.title(T("Guida - Tabella letture Lobaro")); win.transient(self)
        txt = tk.Text(win, wrap="word", width=86, height=30, font=("Segoe UI", 9), padx=10, pady=8, relief="flat")
        sb = tk.Scrollbar(win, command=txt.yview); txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); txt.pack(fill="both", expand=True)
        p = os.path.join(APP_DIR, "LEGGIMI LobaroTabella.txt")
        try:
            with open(p, encoding="utf-8") as f: testo = f.read()
        except Exception:
            testo = motore.__doc__
        txt.insert("1.0", testo); txt.config(state="disabled")
        tk.Button(win, text=T("Chiudi"), command=win.destroy, bg=BLU, fg="white", relief="flat",
                  padx=12, pady=4).pack(pady=6)

    def cambia_lingua(self, _ev=None):
        """Tendina lingua: salva la scelta e riapre la finestra (i testi sono
        creati una volta sola in _build, ricostruirla e' la via piu' sicura)."""
        try:
            scelta = self.lingua_var.get()
            cod = next((k for k, v in motore.LINGUE.items() if v == scelta), "it")
            if cod == motore.LINGUA: return
            self.cfg["lingua"] = cod
            try: impostazioni_salva(self.cfg)
            except Exception: _log_errore("salva lingua")
            self._riavvia = True
            self.destroy()
        except Exception:
            _log_errore("cambia lingua")


if __name__ == "__main__":
    try:
        files = [a for a in sys.argv[1:] if os.path.isfile(a)]
        while True:
            app = App(files)
            app.mainloop()
            if not getattr(app, "_riavvia", False): break
            files = list(app.files)          # riapertura nella lingua nuova, stessi file scelti
    except Exception:
        _log_errore("avvio")
        raise
