@echo off
rem LobaroTabella: trascina uno o piu' CSV export della piattaforma Lobaro su
rem questo file (o doppio clic: si apre la scelta del file). L'Excel esce
rem accanto al CSV con lo stesso nome + " - tabella.xlsx".
rem Percorsi completi (cd /d fallisce con le cartelle aperte via \\server).
title LobaroTabella
set "PYEXE="
where python >nul 2>nul && set "PYEXE=python"
if not defined PYEXE where py >nul 2>nul && set "PYEXE=py -3"
if not defined PYEXE (
  echo Python 3 non trovato: installarlo da python.org con la spunta "Add python.exe to PATH".
  pause
  exit /b 1
)
%PYEXE% "%~dp0LobaroTabella.py" %*
if errorlevel 1 pause
exit /b 0
