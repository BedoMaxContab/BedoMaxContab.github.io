#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LobaroTabella - dal CSV export della piattaforma Lobaro (Device Data) a una
tabella Excel: una riga per matricola, le date di scarico, la lettura di
ogni mese (una colonna per mese) e i dati accessori del telegramma.

PORTATILE: solo libreria standard di Python 3 (niente da installare).
USO:
  - trascinare uno o piu' CSV sul file "Lobaro tabella (trascina il CSV qui).bat"
  - oppure doppio clic sul .bat / sul .py: si apre la scelta del file
  - oppure da riga di comando:  python LobaroTabella.py export1.csv [export2.csv ...]
Il file Excel esce ACCANTO al primo CSV, con lo stesso nome + " - tabella.xlsx".

COSA CONTIENE L'EXCEL
  foglio "Letture mensili": matricola | tipo | costruttore | primo ascolto |
     ultimo scarico | ultima lettura | data lettura (orologio dell'apparecchio) |
     valore al set-day | data set-day | RSSI ultimo | n. telegrammi |
     ... una colonna per ogni mese (ultima lettura ricevuta in quel mese)
  foglio "Consumi mensili": stesse colonne di testa + il consumo di ogni mese
     (differenza fra l'ultima lettura del mese e quella del mese prima;
     per i ripartitori, se la lettura cala = azzeramento: consumo = lettura)
  foglio "Telegrammi": tutti i telegrammi letti, uno per riga.

DA DOVE VENGONO I NUMERI
  1) dal TELEGRAMMA wM-Bus decodificato qui (standard EN 13757-3, telegrammi
     non cifrati CI 0x78/0x7a/0x72): lettura attuale, valore e data del
     set-day (storage 1), orologio dell'apparecchio;
  2) ripartitori 'BMP' (Fantini, formato proprietario): decodifica dedicata;
  3) se il telegramma non si decodifica, la colonna "Main Value" della
     piattaforma.
La colonna "fonte" del foglio Telegrammi dice quale delle tre.
"""
import os, re, sys, csv, zipfile, traceback
from datetime import datetime
from collections import OrderedDict

VERSIONE = "2.1 del 09/09/2026"
MESI_MAX = 24        # colonne mensili al massimo (a ritroso dall'ultimo mese)

# ----------------------------------------------------------------- utilita'
def zfill8(m):
    m = (m or "").strip()
    return m.zfill(8) if m.isdigit() and len(m) < 8 else m

def parse_dt(s):
    """'06.08.2026 16:43:47' (piattaforma Lobaro) o ISO -> datetime|None"""
    s = (s or "").strip()
    for fmt in ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d/%m/%Y %H:%M:%S",
                "%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d",
                "%d.%m.%y %H:%M:%S", "%d.%m.%y %H:%M", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(s[:19], fmt)
        except ValueError:
            pass
    return None

def num(s):
    s = (s or "").strip()
    if not s: return None
    m = re.match(r"^-?[\d.,]+", s)
    if not m: return None
    t = m.group(0)
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", ".")
    try: return float(t)
    except ValueError: return None

def hexbytes(h):
    h = (h or "").strip().lower()
    if h.startswith("0x"): h = h[2:]
    if len(h) % 2 or not re.match(r"^[0-9a-f]*$", h): return b""
    return bytes.fromhex(h)

def bcd(bs):
    """BCD little-endian -> int (None se cifre non valide)"""
    s = "".join("%02x" % b for b in reversed(bs))
    if not s.isdigit(): return None
    return int(s)

def data_G(bs):
    """tipo G (2 byte): data"""
    if len(bs) < 2: return None
    g = bs[0] | (bs[1] << 8)
    d = g & 0x1f; mo = (g >> 8) & 0x0f; y = ((g >> 5) & 0x07) | ((g >> 9) & 0x78)
    if not (1 <= d <= 31 and 1 <= mo <= 12): return None
    try: return datetime(2000 + y, mo, d)
    except ValueError: return None

def data_F(bs):
    """tipo F (4 byte): data e ora"""
    if len(bs) < 4: return None
    mi = bs[0] & 0x3f; h = bs[1] & 0x1f; d = bs[2] & 0x1f; mo = bs[3] & 0x0f
    y = ((bs[2] & 0xe0) >> 5) | ((bs[3] & 0xf0) >> 1)
    if not (1 <= d <= 31 and 1 <= mo <= 12 and h < 24 and mi < 60): return None
    try: return datetime(2000 + y, mo, d, h, mi)
    except ValueError: return None

# ------------------------------------------------ decodifica telegramma wM-Bus
LUNG = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 4, 6: 6, 7: 8, 9: 1, 10: 2, 11: 3, 12: 4, 14: 6}

def vif_info(vif):
    """VIF primario -> (grandezza, moltiplicatore, unita')"""
    if vif == 0x6e: return ("HCA", 1.0, "unita'")
    if 0x10 <= vif <= 0x17: return ("Volume", 10 ** (vif - 0x16), "mc")
    if 0x00 <= vif <= 0x07: return ("Energia", 10 ** (vif - 0x03), "kWh")
    if 0x08 <= vif <= 0x0f: return ("Energia", 10 ** (vif - 0x08) / 3.6e6, "kWh")
    if 0x28 <= vif <= 0x2f: return ("Potenza", 10 ** (vif - 0x2b), "kW")
    if 0x58 <= vif <= 0x5b: return ("T mandata", 10 ** (vif - 0x5b), "C")
    if 0x5c <= vif <= 0x5f: return ("T ritorno", 10 ** (vif - 0x5f), "C")
    if 0x64 <= vif <= 0x67: return ("T ambiente", 10 ** (vif - 0x67), "C")
    if vif == 0x6c: return ("Data", 1.0, "")
    if vif == 0x6d: return ("DataOra", 1.0, "")
    if 0x70 <= vif <= 0x73: return ("Durata media", 1.0, "")
    if 0x74 <= vif <= 0x77: return ("Durata", 1.0, "")
    return (None, 1.0, "")

def records_mbus(app):
    """Legge i data record dell'application layer (dopo l'header).
    Ritorna lista di dict {storage, tariffa, grandezza, valore, unita', vif}.
    Si ferma al blocco 'manufacturer specific' (0x0F/0x1F)."""
    out, i, n = [], 0, len(app)
    while i < n:
        dif = app[i]; i += 1
        if dif in (0x0f, 0x1f): break
        if dif == 0x2f: continue            # riempimento
        df = dif & 0x0f
        storage = (dif >> 6) & 1; tariffa = 0; ext = dif & 0x80; k = 0
        while ext and i < n:
            dife = app[i]; i += 1
            storage |= (dife & 0x0f) << (1 + 4 * k)
            tariffa |= ((dife >> 4) & 3) << (2 * k)
            ext = dife & 0x80; k += 1
        if i >= n: break
        vif = app[i]; i += 1
        vifs = [vif]; ext = vif & 0x80
        while ext and i < n:
            v = app[i]; i += 1; vifs.append(v); ext = v & 0x80
        if df == 0x0d:                      # lunghezza variabile
            if i >= n: break
            lv = app[i]; i += 1
            if lv < 0xc0: i += lv
            else: i += 2 * (lv & 0x0f) if lv < 0xe0 else 0
            continue
        if df == 0x08 or df == 0x0f:        # selezione / speciale: senza dati
            continue
        ln = LUNG.get(df)
        if ln is None or i + ln > n: break
        raw = app[i:i + ln]; i += ln
        base = vifs[0] & 0x7f
        if vifs[0] in (0xfd, 0xfb) or base == 0x7f or base == 0x7e:
            continue                        # estensioni: non servono qui
        gr, mult, un = vif_info(base)
        if gr is None: continue
        val = None
        if gr == "Data": val = data_G(raw)
        elif gr == "DataOra": val = data_F(raw)
        elif df in (0x09, 0x0a, 0x0b, 0x0c, 0x0e):
            b = bcd(raw); val = None if b is None else b * mult
        elif df == 0x05:
            import struct
            try: val = struct.unpack("<f", raw)[0] * mult
            except Exception: val = None
        elif ln:
            val = int.from_bytes(raw, "little", signed=(df in (1, 2, 3, 4, 6, 7)) and False) * mult
        out.append({"storage": storage, "tariffa": tariffa, "grandezza": gr,
                    "valore": val, "unita": un, "vif": base})
    return out

def decodifica_telegramma(hexstr):
    """Telegramma wM-Bus (senza CRC) -> dict con: valore (lettura attuale),
    unita, grandezza, set_valore, set_data, orologio, fonte='telegramma';
    None se cifrato/non riconosciuto."""
    b = hexbytes(hexstr)
    if len(b) < 12: return None
    L = b[0]
    if b[1] not in (0x44, 0x46, 0x47, 0x48): return None   # SND_NR e affini
    ci = b[10]
    p = 11
    if ci == 0x7a:                       # header corto: ACC STS CW(2)
        if len(b) < 15: return None
        cw = b[13] | (b[14] << 8); p = 15; sts = b[12]
        if (cw >> 8) & 0x1f: return None  # cifrato
    elif ci == 0x72:                     # header lungo: ID(4) M(2) V T ACC STS CW(2)
        if len(b) < 23: return None
        cw = b[21] | (b[22] << 8); p = 23; sts = b[20]
        if (cw >> 8) & 0x1f: return None
    elif ci in (0x78,):                  # nessun header
        p = 11; sts = None
    else:
        return None
    app = b[p:1 + L] if 1 + L <= len(b) else b[p:]
    recs = records_mbus(app)
    if not recs: return None
    r = {"fonte": "telegramma", "valore": None, "unita": "", "grandezza": "",
         "set_valore": None, "set_data": None, "orologio": None, "storici": [],
         "batteria": batt_da_stato(sts), "errore": sts}
    val_st, data_st = {}, {}          # per numero di storage
    for x in recs:
        if x["grandezza"] in ("HCA", "Volume", "Energia") and x["tariffa"] == 0:
            if x["storage"] not in val_st and x["valore"] is not None:
                val_st[x["storage"]] = (x["valore"], x["unita"], x["grandezza"])
        elif x["grandezza"] == "Data" and x["storage"] not in data_st and x["valore"]:
            data_st[x["storage"]] = x["valore"]
        elif x["grandezza"] == "DataOra" and x["storage"] == 0 and r["orologio"] is None:
            r["orologio"] = x["valore"]
    if not val_st: return None
    if 0 in val_st:
        r["valore"], r["unita"], r["grandezza"] = val_st[0]
    else:                               # solo valori memorizzati: il piu' "vicino"
        st = min(val_st)
        r["valore"], r["unita"], r["grandezza"] = val_st[st]
        r["fonte"] = "telegramma (storage %d)" % st
    # valori memorizzati con la loro data (set-day = storage 1, fine mese ecc.)
    for st in sorted(val_st):
        if st and st in data_st:
            r["storici"].append((data_st[st], val_st[st][0]))
    if 1 in val_st:
        r["set_valore"] = val_st[1][0]; r["set_data"] = data_st.get(1)
    elif r["storici"]:
        r["set_data"], r["set_valore"] = r["storici"][0]
    return r

def decodifica_bmp(hexstr):
    """Ripartitori 'BMP' (Fantini, M-field 0xb009, CI 0x78, corpo 0x0F):
    parole 16 bit LE dopo 0x0F, [4] = lettura in decimi (stagione), [5]/[6]
    temperature x100. Formato ricostruito (da verificare col lettore)."""
    try:
        h = (hexstr or "").strip().lower()
        if h.startswith("0x"): h = h[2:]
        if len(h) < 24 or h[2:4] != "44" or h[4:8] != "b009": return None
        L = int(h[0:2], 16)
        if h[18:20] != "08" or h[20:22] != "78" or h[22:24] != "0f": return None
        corpo = h[24:24 + 2 * (L - 11)]
        w = [int(corpo[k + 2:k + 4] + corpo[k:k + 2], 16) for k in range(0, len(corpo) - 3, 4)]
        if L == 0x25 or len(w) < 6: return None
        return {"fonte": "BMP", "valore": w[4] / 10.0, "unita": "unita'", "grandezza": "HCA",
                "set_valore": None, "set_data": None, "orologio": None, "storici": [], "batteria": None,
                "t1": w[5] / 100.0 if w[5] else None}
    except Exception:
        return None

# ------------------------------------------------------------ lettura CSV
def leggi_csv(path):
    tel = []
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
        testa = f.read(4096); f.seek(0)
        delim = ";" if testa.count(";") >= testa.count(",") else ","
        rd = csv.DictReader(f, delimiter=delim)
        cols = rd.fieldnames or []
        if "ID (DLL)" not in cols:
            raise ValueError("%s: non sembra un CSV Lobaro (manca la colonna 'ID (DLL)')" % os.path.basename(path))
        for r in rd:
            mid = zfill8(r.get("ID (DLL)"))
            if not mid: continue
            ricev = parse_dt(r.get("Received"))
            dt = parse_dt(r.get("wMBUS Received")) or ricev
            if not dt: continue
            raw = (r.get("Telegram") or "").strip()
            d = decodifica_telegramma(raw) or decodifica_bmp(raw)
            mv = (r.get("Main Value") or "").strip()
            if d is None:
                v = num(mv)
                d = {"fonte": "piattaforma" if v is not None else "-", "valore": v,
                     "unita": re.sub(r"^[-\d.,\s]+", "", mv)[:20], "grandezza": "",
                     "set_valore": None, "set_data": None, "orologio": None, "storici": [], "batteria": None}
            tel.append({"matricola": mid, "dt": dt, "ricevuto": ricev or dt,
                        "mf": (r.get("M-Field") or "").strip(),
                        "tipo": (r.get("Type (DLL)") or "").strip(),
                        "ver": (r.get("Version") or "").strip(),
                        "rssi": num(r.get("RSSI")), "ci": (r.get("CI") or "").strip(),
                        "main": mv, "file": os.path.basename(path), **d})
    return tel

def _stato_int(v):
    if v is None: return None
    s = str(v).strip()
    if not s or s.lower() in ("x x x", "xxx", "-"): return None
    try: return int(float(s.replace(",", ".")))
    except ValueError: return None

# Tabella ERRORI SIEMECA (Siemens, documento "Errori Antenne" fornito da BEDO
# il 09/09/2026): i codici sono SOMME ARITMETICHE dei 5 errori base.
SIEMECA_BASE = [                      # (codice, chiave testo)
    (4,   "batteria: meno di 15 mesi di vita utile"),
    (40,  "hardware difettoso (errore permanente)"),
    (80,  "fuori dalle soglie di funzionamento (errore temporaneo)"),
    (136, "errore permanente di comunicazione"),
    (144, "errore temporaneo di comunicazione"),
]

# le 13 combinazioni del documento Siemens (NB: 208 = "errore 3 e 5" e' un OR
# di bit, 176 = "errore 2 e 4" una somma: la tabella ufficiale comanda)
SIEMECA_TABELLA = {4: [4], 40: [40], 80: [80], 136: [136], 144: [144],
                   44: [4, 40], 84: [4, 80], 140: [4, 136], 148: [4, 144],
                   176: [40, 136], 184: [40, 144], 216: [80, 136], 208: [80, 144]}

def _siemeca_scomponi(n):
    """n -> lista di codici base: prima la tabella ufficiale, poi la somma
    aritmetica, poi l'OR dei bit (al massimo uno fra 136 e 144); None se
    non scomponibile"""
    if n in SIEMECA_TABELLA: return SIEMECA_TABELLA[n]
    codici = [c for c, _ in SIEMECA_BASE]
    for modo in ("somma", "or"):
        best = None
        for mask in range(1, 1 << len(codici)):
            scelti = [codici[i] for i in range(len(codici)) if mask >> i & 1]
            if 136 in scelti and 144 in scelti: continue
            tot = sum(scelti) if modo == "somma" else __import__("functools").reduce(lambda a, b: a | b, scelti)
            if tot != n: continue
            if best is None or len(scelti) < len(best): best = scelti
        if best: return best
    return None

def descrivi_stato_siemeca(n):
    """significato secondo la tabella Siemeca (ripartitori/contatori Siemens
    letti dal gateway WTT16): 04 batteria, 40 hardware, 80 soglie, 136/144
    comunicazione, e le loro somme (44, 84, 140, 148, 176, 184, 216, 208...)"""
    if n == 0: return T("nessun errore")
    parti = _siemeca_scomponi(n)
    if not parti:
        return "%s %d (%s)" % (T("codice"), n, T("non in tabella Siemeca"))
    nomi = dict(SIEMECA_BASE)
    return " + ".join(T(nomi[c]) for c in parti)

def descrivi_stato(v, siemens=False):
    """Byte di stato -> testo leggibile. Con siemens=True (file .rep del
    WTT16 o telegrammi con M-Field LSE) usa la tabella Siemeca; altrimenti
    la norma EN 13757-3: bit 0-1 errore applicativo (1 occupato, 2 errore,
    3 allarme), bit 2 batteria, bit 3 permanente, bit 4 temporaneo, bit 5-7
    costruttore."""
    n = _stato_int(v)
    if n is None: return ""
    if siemens: return descrivi_stato_siemeca(n)
    if n == 0: return T("nessun errore")
    parti = []
    app = n & 3
    if app == 1: parti.append(T("occupato"))
    elif app == 2: parti.append(T("errore applicativo"))
    elif app == 3: parti.append(T("allarme"))
    if n & 4: parti.append(T("batteria in esaurimento"))
    if n & 8: parti.append(T("errore permanente"))
    if n & 16: parti.append(T("errore temporaneo"))
    cost = n & 0xE0
    if cost: parti.append("%s %d" % (T("codice costruttore"), cost))
    return " + ".join(parti)

def batt_da_stato(v):
    """Byte di stato M-Bus (EN 13757-3): bit 2 = POWER LOW -> 'scarica'/'ok'/None"""
    if v is None: return None
    s = str(v).strip()
    if not s or s.lower() in ("x x x", "xxx", "-"): return None
    try: n = int(float(s.replace(",", ".")))
    except ValueError: return None
    return "scarica" if (n >> 2) & 1 else "ok"

def _fine_mese(y, m):
    if m == 12: return datetime(y, 12, 31)
    return datetime(y, m + 1, 1) - __import__("datetime").timedelta(days=1)

def leggi_rep(path):
    """File .rep / .BIL del gateway WTT16 (intestazioni inglesi 'No.\tDevice ID'
    o tedesche 'Zaehler'): un 'telegramma' per contatore con la lettura
    attuale, il valore al set-day e le 18 letture di fine mese (Stat. value
    1..18 a ritroso dalla 'Statistic date'), piu' lo stato batteria."""
    with open(path, encoding="cp1252", errors="replace") as f:
        lines = [l.rstrip("\n").rstrip("\r") for l in f]
    hdr, cols = None, None
    for i, l in enumerate(lines):
        if l.startswith("Zaehler") or l.startswith("No.\t") or l.startswith("Device\t"):
            hdr, cols = i, l.split("\t"); break
    if hdr is None:
        raise ValueError("%s: non sembra un .rep/.BIL WTT16 (intestazione contatori non trovata)" % os.path.basename(path))
    # data dello scarico (riga del gateway in testa al file), se c'e'
    ricev = None
    for l in lines[:hdr]:
        m = re.search(r"(\d{2}\.\d{2}\.\d{4})\t\d\t(\d{2}:\d{2}:\d{2})", l)
        if m: ricev = parse_dt(m.group(1) + " " + m.group(2)); break
    ALIAS = {"mat": ("KKundeNr101", "Device ID"), "date": ("ZDatR233", "Readout date", "ZDatR133"),
             "time": ("ZUhrR234", "Readout time", "ZUhrR134"), "sw": ("KSWIndZ252", "Software version"),
             "energy": ("CVxKVal102", "Cum. energy", "CEnKVal102"), "volume": ("CVolKVal103", "Cum. volume"),
             "medium": ("KMed187", "Medium"), "stich": ("CVxSt1Val107", "Set day value", "CEnStLVal107"),
             "stichv": ("CVolStLVal108",), "stichd": ("ZDatStL110", "Set day date"),
             "sta1": ("ZDatSta1", "Statistic date"), "stato": ("SFehler350", "Error code", "SFehler250", "SFehler"),
             "errdate": ("Error date", "ZDatFehler"),
             "manu": ("Manufacturer", "KHerst")}
    def find(names):
        for j, c in enumerate(cols):
            cc = (c or "").strip()
            for n in names:
                if cc == n or cc.startswith(n): return j
        return None
    ix = {k: find(v) for k, v in ALIAS.items()}
    stat_idx = [find(("CVxStat%dVal" % k, "Stat. value%d" % k)) for k in range(1, 19)]
    if ix["mat"] is None:
        raise ValueError("%s: colonna matricola (Device ID / KKundeNr101) non trovata" % os.path.basename(path))
    MEDIA = {"8": "Heat Cost", "HCA": "Heat Cost", "7": "Warm Water", "22": "Warm Water",
             "6": "Water", "4": "Heat"}
    UNITA = {"Heat Cost": "unita'", "Warm Water": "mc", "Water": "mc", "Heat": "kWh"}
    out = []
    for l in lines[hdr + 1:]:
        if not l.strip(): continue
        p_ = l.split("\t")
        def g(i): return p_[i].strip() if (i is not None and i < len(p_)) else ""
        medium = g(ix["medium"]); sw = g(ix["sw"])
        if not medium and sw != "51": continue          # nodi di rete / gateway
        mat = re.sub(r"\D", "", g(ix["mat"]))
        if len(mat) < 5: continue
        dt = parse_dt((g(ix["date"]) + " " + g(ix["time"])).strip())
        if dt and dt.year < 100: dt = dt.replace(year=dt.year + 2000)
        mu = medium.upper()
        tipo = MEDIA.get(mu, "")
        if not tipo:
            tipo = {"44": "Heat Cost", "53": "Water", "65": "Warm Water"}.get(sw, medium or "Water")
        is_hca = tipo == "Heat Cost"
        e_val, v_val = num(g(ix["energy"])), num(g(ix["volume"]))
        if e_val is not None and v_val is None: lettura = e_val
        elif v_val is not None and e_val is None: lettura = v_val
        else: lettura = e_val if is_hca else v_val
        storici = []
        d1 = parse_dt(g(ix["sta1"]))
        if d1:
            if d1.year < 100: d1 = d1.replace(year=d1.year + 2000)
            y, m = d1.year, d1.month
            for k in range(18):
                mm, yy = m - k, y
                while mm <= 0: mm += 12; yy -= 1
                v = num(g(stat_idx[k])) if stat_idx[k] is not None else None
                if v is not None: storici.append((_fine_mese(yy, mm), v))
        std = parse_dt(g(ix["stichd"]))
        if std and std.year < 100: std = std.replace(year=std.year + 2000)
        sv_e, sv_v = num(g(ix["stich"])), num(g(ix["stichv"]))
        stich = sv_e if is_hca else (sv_v if sv_v is not None else sv_e)
        if not dt: dt = ricev or datetime.now()
        out.append({"matricola": zfill8(mat), "dt": dt, "ricevuto": ricev or dt,
                    "mf": g(ix["manu"]) or "WTT16", "tipo": tipo, "ver": sw, "rssi": None, "ci": "",
                    "main": "", "file": os.path.basename(path), "fonte": "rep",
                    "valore": lettura, "unita": UNITA.get(tipo, ""), "grandezza": "HCA" if is_hca else "Volume",
                    "set_valore": stich, "set_data": std, "orologio": dt, "storici": storici,
                    "batteria": batt_da_stato(g(ix["stato"])), "errore": _stato_int(g(ix["stato"])),
                    "errore_data": g(ix.get("errdate")) if ix.get("errdate") is not None else ""})
    if not out:
        raise ValueError("%s: nessun contatore valido nel file" % os.path.basename(path))
    return out

def leggi_file(path):
    """CSV Lobaro oppure .rep/.BIL WTT16, a seconda dell'estensione/contenuto."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".rep", ".bil"):
        if not LEGGE_REP:
            raise ValueError("%s: %s" % (os.path.basename(path), T("questo programma legge solo i CSV della piattaforma Lobaro")))
        return leggi_rep(path)
    if ext == ".csv": return leggi_csv(path)
    try: return leggi_csv(path)
    except Exception:
        if not LEGGE_REP: raise
        return leggi_rep(path)

# ---------------------------------------------------------- elaborazione
def mese(dt): return dt.strftime("%Y-%m")

def elabora(tel):
    per = OrderedDict()
    for t in sorted(tel, key=lambda x: (x["matricola"], x["dt"])):
        m = per.setdefault(t["matricola"], {"tel": []})
        m["tel"].append(t)
    mesi = set(mese(t["dt"]) for t in tel)
    for t in tel:
        for d, v in t["storici"]:
            mesi.add(mese(d))
    # finestra: al massimo MESI_MAX mesi a ritroso dall'ultimo (i .rep di
    # apparecchi muti da anni porterebbero colonne del 2015)
    ultimo = max(mese(t["dt"]) for t in tel)
    y, m = int(ultimo[:4]), int(ultimo[5:])
    m0 = m - (MESI_MAX - 1); y0 = y
    while m0 <= 0: m0 += 12; y0 -= 1
    primo = "%04d-%02d" % (y0, m0)
    mesi = sorted(x for x in mesi if x >= primo)
    righe = []
    for mat, m in per.items():
        ts = m["tel"]
        con_val = [t for t in ts if t["valore"] is not None]
        ult = con_val[-1] if con_val else ts[-1]
        r = OrderedDict()
        r["Matricola"] = mat
        r["Tipo"] = ult["tipo"] or ult["grandezza"]
        r["Costruttore"] = ult["mf"]
        r["Primo ascolto"] = ts[0]["dt"]
        r["Ultimo scarico"] = max(t["ricevuto"] for t in ts)
        r["Ultima lettura"] = ult["valore"]
        r["Unita'"] = ult["unita"]
        r["Data lettura (orologio app.)"] = ult["orologio"] or ult["dt"]
        con_set = [t for t in ts if t["set_valore"] is not None]
        r["Valore al set-day"] = con_set[-1]["set_valore"] if con_set else None
        r["Data set-day"] = con_set[-1]["set_data"] if con_set else None
        r["RSSI ultimo"] = ult["rssi"]
        r["N. telegrammi"] = len(ts)
        r["Fonte"] = ult["fonte"]
        bt = [t.get("batteria") for t in ts if t.get("batteria")]
        r["Batteria"] = bt[-1] if bt else None
        er = [t.get("errore") for t in ts if t.get("errore") is not None]
        r["Errore (cod.)"] = er[-1] if er else None
        siem = ult["fonte"] == "rep" or (ult.get("mf") or "").upper() == "LSE"
        r["Significato errore"] = descrivi_stato(er[-1], siemens=siem) if er else ""
        # lettura del mese: 1) valore MEMORIZZATO dall'apparecchio con data in
        # quel mese (fine mese / set-day: e' la lettura esatta), altrimenti
        # 2) l'ultimo telegramma ricevuto in quel mese
        letture, memo = {}, {}
        for t in con_val:
            letture[mese(t["dt"])] = t["valore"]     # ordinati: resta l'ultimo del mese
        for t in ts:
            for d, v in t["storici"]:
                if v is None: continue
                mm = mese(d)
                if mm not in memo or d >= memo[mm][0]:
                    memo[mm] = (d, v)
        for mm, (d, v) in memo.items():
            letture[mm] = v
        r["_letture"] = letture
        r["_memo"] = memo
        hca = (r["Tipo"] or "").lower().startswith("heat cost") or ult["grandezza"] == "HCA"
        cons, prev = {}, None
        for mm in mesi:
            v = letture.get(mm)
            if v is None: continue
            if prev is not None:
                if hca and v < prev: cons[mm] = v          # azzerato nel mese
                else: cons[mm] = v - prev
            prev = v
        r["_consumi"] = cons
        righe.append(r)
    # in uscita: dal mese PIU' RECENTE al piu' vecchio (richiesta 09/09/2026)
    return righe, list(reversed(mesi))

# ---------------------------------------------------------- scrittura xlsx
def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))

def _col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26); s = chr(65 + r) + s
    return s

def _excel_dt(dt):
    d0 = datetime(1899, 12, 30)
    delta = dt - d0
    return delta.days + delta.seconds / 86400.0


# ------------------------------------------------ lingue (it / en / de)
# Chiavi = testo ITALIANO usato nel codice; T(s) restituisce la traduzione
# nella lingua attiva (LINGUA) o il testo stesso se non esiste.
LINGUA = "it"
LINGUE = {"it": "Italiano", "en": "English", "de": "Deutsch"}
_MESI = {"it": ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"],
         "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
         "de": ["Jan", "Feb", "Mrz", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"]}
TESTI = {
 "it": {"Tabella letture Lobaro (finestra)": "Tabella letture Lobaro", "Matricola (pdf)": "Matricola"},
 "en": {
  # colonne e fogli
  "Matricola": "Meter ID", "Tipo": "Type", "Costruttore": "Manufacturer", "Primo ascolto": "First received",
  "Ultimo scarico": "Last download", "Ultima lettura": "Last reading", "Unita'": "Unit",
  "Data lettura (orologio app.)": "Reading date (device clock)", "Valore al set-day": "Set-day value",
  "Data set-day": "Set-day date", "RSSI ultimo": "Last RSSI", "N. telegrammi": "No. of telegrams",
  "Fonte": "Source", "Batteria": "Battery", "Errore (cod.)": "Error (code)", "Significato errore": "Error meaning",
  "Ricevuto (wM-Bus)": "Received (wM-Bus)", "Scaricato dalla piattaforma": "Downloaded from platform",
  "Versione": "Version", "Lettura": "Reading", "Orologio apparecchio": "Device clock",
  "Main Value piattaforma": "Platform Main Value", "File": "File", "Data memorizzata": "Stored date",
  "Valore": "Value", "Da telegramma del": "From telegram of",
  "Letture mensili": "Monthly readings", "Consumi mensili": "Monthly consumption",
  "Valori memorizzati": "Stored values", "Telegrammi": "Telegrams",
  "tabella letture Lobaro - generata il": "Lobaro readings table - generated on",
  "Tabella letture Lobaro": "Lobaro readings table", "generata il": "generated on", "mesi da": "months from",
  "a": "to", "blocco": "block", "pag.": "page", "matricole": "meters",
  # PDF intestazioni a capo
  "Matricola (pdf)": "Meter ID", "Costrut-|tore": "Manu-|facturer", "Ultimo|scarico": "Last|download", "Ultima|lettura": "Last|reading",
  "Valore al|set-day": "Set-day|value", "Data|set-day": "Set-day|date", "N. tele-|grammi": "No. of|telegrams",
  "Batt.": "Batt.", "Err.": "Err.",
  # valori
  "unita'": "units", "scarica": "low", "ok": "ok", "telegramma": "telegram", "piattaforma": "platform",
  "rep": "rep", "BMP": "BMP", "-": "-",
  "batteria: meno di 15 mesi di vita utile": "battery: less than 15 months of life left",
  "hardware difettoso (errore permanente)": "faulty hardware (permanent error)",
  "fuori dalle soglie di funzionamento (errore temporaneo)": "outside operating thresholds (temporary error)",
  "errore permanente di comunicazione": "permanent communication error",
  "errore temporaneo di comunicazione": "temporary communication error",
  "codice": "code", "non in tabella Siemeca": "not in the Siemeca table",
  "nessun errore": "no error", "occupato": "busy", "errore applicativo": "application error",
  "allarme": "alarm", "batteria in esaurimento": "low battery", "errore permanente": "permanent error",
  "errore temporaneo": "temporary error", "codice costruttore": "manufacturer code",
  "Creato": "Created", "telegrammi": "telegrams", "mesi": "months",
  "letture dal telegramma": "readings from telegram", "dalla piattaforma": "from platform",
  "da .rep WTT16": "from WTT16 .rep", "senza valore": "without value",
  "Nessun telegramma nei file.": "No telegram in the files.",
  # finestra
  "?  Guida": "?  Help", "Cartelle": "Folders", "Lingua": "Language",
  "Tabella letture Lobaro (finestra)": "Lobaro readings table",
  "cambia...": "change...", "File scelti:": "Selected files:",
  "ANTEPRIMA - Letture mensili (una riga per matricola; nell'Excel ci sono anche Consumi mensili, Valori memorizzati e Telegrammi)":
      "PREVIEW - Monthly readings (one row per meter; the Excel file also has Monthly consumption, Stored values and Telegrams)",
  "Pronto. Scegli il CSV esportato dalla piattaforma Lobaro.": "Ready. Choose the CSV exported from the Lobaro platform.",
  "PRENDO I CSV DA:": "READ CSV FROM:", "ARCHIVIO (Excel, PDF, copia dei CSV):": "ARCHIVE (Excel, PDF, CSV copies):",
  "Cartelle NON impostate: premi 'Cartelle' per dire dove prendere i CSV e dove archiviare il materiale.":
      "Folders NOT set: press 'Folders' to say where to read the CSV files and where to archive the output.",
  "CARTELLE DI LAVORO": "WORKING FOLDERS", "PRIMO AVVIO: ": "FIRST START: ",
  "Dimmi dove PRENDERE i CSV esportati dalla piattaforma Lobaro e dove ARCHIVIARE\ntutto il materiale (tabelle Excel, PDF di stampa e una copia dei CSV elaborati).\nLe due cartelle possono anche coincidere. Si cambiano quando vuoi, da qui.":
      "Tell me where to READ the CSV files exported from the Lobaro platform and where to ARCHIVE\neverything (Excel tables, print PDFs and a copy of the processed CSV files).\nThe two folders may be the same. You can change them any time, from here.",
  "Prendo i CSV da (cartella dei download):": "Read CSV from (download folder):",
  "Archivio del materiale (Excel, PDF, CSV):": "Archive (Excel, PDF, CSV):", "Sfoglia...": "Browse...",
  "Consiglio: l'archivio su una cartella di rete condivisa, cosi' lo vedono tutti.": "Tip: put the archive on a shared network folder, so everybody can see it.",
  "Compila tutte e due le cartelle.": "Fill in both folders.",
  "La cartella non esiste:\n%s\n\nLa creo?\n\n(INVIO = Si'   -   ESC = No)": "The folder does not exist:\n%s\n\nCreate it?\n\n(ENTER = Yes   -   ESC = No)",
  "Non riesco a crearla: %s": "Cannot create it: %s", "Non riesco a salvare impostazioni.cfg: %s": "Cannot save impostazioni.cfg: %s",
  "Cartelle salvate. Ora '1. Scegli i file...'": "Folders saved. Now '1. Choose files...'",
  "Salva": "Save", "Annulla": "Cancel", "(nessuno)": "(none)",
  "Scegli il CSV Lobaro o il file .rep/.BIL del gateway WTT16": "Choose the Lobaro CSV or the WTT16 gateway .rep/.BIL file",
  "CSV Lobaro / .rep WTT16": "Lobaro CSV / WTT16 .rep", "CSV Lobaro": "Lobaro CSV", "Tutti i file": "All files",
  "questo programma legge solo i CSV della piattaforma Lobaro": "this program reads only the Lobaro platform CSV files",
  "1. Scegli i file (CSV Lobaro)...": "1. Choose files (Lobaro CSV)...",
  "FILE DA ELABORARE\nCSV Lobaro": "FILES TO PROCESS\nLobaro CSV",
  "Scegli il CSV esportato dalla piattaforma Lobaro": "Choose the CSV exported from the Lobaro platform",
  "%d file scelti. Premi '2. Crea tabella Excel + PDF'.": "%d files selected. Press '2. Create Excel + PDF table'.",
  "Elenco file svuotato.": "File list cleared.", "Tabella": "Table",
  "Prima scegli almeno un CSV (pulsante 1).": "First choose at least one file (button 1).",
  "Prima imposta le cartelle (pulsante 'Cartelle' in alto).": "First set the folders ('Folders' button at the top).",
  "Esiste gia':\n%s\n\nLo sovrascrivo?\n\n(INVIO = Si'   -   ESC = No)": "Already exists:\n%s\n\nOverwrite it?\n\n(ENTER = Yes   -   ESC = No)",
  "Leggo i telegrammi e preparo la tabella...": "Reading telegrams and building the table...",
  "ERRORE: %s": "ERROR: %s", "(dettagli in errori.txt)": "(details in errori.txt)",
  "Creati in archivio Excel e PDF: %s%s   (3 = Excel, 4 = PDF da stampare)": "Excel and PDF created in the archive: %s%s   (3 = Excel, 4 = PDF to print)",
  ", file copiati: %d": ", files copied: %d",
  "Excel creato, anteprima non riuscita (vedi errori.txt)": "Excel created, preview failed (see errori.txt)",
  "Chiudi": "Close", "Guida - Tabella letture Lobaro": "Help - Lobaro readings table",
  "FILE DA ELABORARE\nCSV Lobaro o .rep WTT16": "FILES TO PROCESS\nLobaro CSV or WTT16 .rep",
  "1. Scegli i file (CSV Lobaro / .rep WTT16)...": "1. Choose files (Lobaro CSV / WTT16 .rep)...",
  "Togli dall'elenco": "Clear list", "TABELLA\nExcel + PDF": "TABLE\nExcel + PDF",
  "2. Crea tabella Excel + PDF": "2. Create Excel + PDF table", "3. Apri l'Excel": "3. Open Excel",
  "4. Apri il PDF (stampa)": "4. Open PDF (print)", "Apri la cartella archivio": "Open archive folder",
  "Cambio lingua: la finestra si riapre.": "Language change: the window will reopen.",
 },
 "de": {
  "Matricola": "Zaehlernummer", "Tipo": "Typ", "Costruttore": "Hersteller", "Primo ascolto": "Erster Empfang",
  "Ultimo scarico": "Letzter Abruf", "Ultima lettura": "Letzter Stand", "Unita'": "Einheit",
  "Data lettura (orologio app.)": "Ablesedatum (Geraeteuhr)", "Valore al set-day": "Stichtagswert",
  "Data set-day": "Stichtag", "RSSI ultimo": "Letzter RSSI", "N. telegrammi": "Anzahl Telegramme",
  "Fonte": "Quelle", "Batteria": "Batterie", "Errore (cod.)": "Fehler (Code)", "Significato errore": "Fehlerbedeutung",
  "Ricevuto (wM-Bus)": "Empfangen (wM-Bus)", "Scaricato dalla piattaforma": "Von Plattform abgerufen",
  "Versione": "Version", "Lettura": "Stand", "Orologio apparecchio": "Geraeteuhr",
  "Main Value piattaforma": "Main Value Plattform", "File": "Datei", "Data memorizzata": "Speicherdatum",
  "Valore": "Wert", "Da telegramma del": "Aus Telegramm vom",
  "Letture mensili": "Monatsstaende", "Consumi mensili": "Monatsverbrauch",
  "Valori memorizzati": "Gespeicherte Werte", "Telegrammi": "Telegramme",
  "tabella letture Lobaro - generata il": "Lobaro Ablesetabelle - erstellt am",
  "Tabella letture Lobaro": "Lobaro Ablesetabelle", "generata il": "erstellt am", "mesi da": "Monate von",
  "a": "bis", "blocco": "Block", "pag.": "Seite", "matricole": "Zaehler",
  "Matricola (pdf)": "Zaehler-|nummer", "Costrut-|tore": "Her-|steller", "Ultimo|scarico": "Letzter|Abruf", "Ultima|lettura": "Letzter|Stand",
  "Valore al|set-day": "Stichtags-|wert", "Data|set-day": "Stich-|tag", "N. tele-|grammi": "Anzahl|Telegr.",
  "Batt.": "Batt.", "Err.": "Fehl.",
  "unita'": "Einheiten", "scarica": "schwach", "ok": "ok", "telegramma": "Telegramm", "piattaforma": "Plattform",
  "rep": "rep", "BMP": "BMP", "-": "-",
  "batteria: meno di 15 mesi di vita utile": "Batterie: weniger als 15 Monate Restlaufzeit",
  "hardware difettoso (errore permanente)": "Hardware defekt (permanenter Fehler)",
  "fuori dalle soglie di funzionamento (errore temporaneo)": "ausserhalb der Betriebsgrenzen (temporaerer Fehler)",
  "errore permanente di comunicazione": "permanenter Kommunikationsfehler",
  "errore temporaneo di comunicazione": "temporaerer Kommunikationsfehler",
  "codice": "Code", "non in tabella Siemeca": "nicht in der Siemeca-Tabelle",
  "nessun errore": "kein Fehler", "occupato": "belegt", "errore applicativo": "Anwendungsfehler",
  "allarme": "Alarm", "batteria in esaurimento": "Batterie schwach", "errore permanente": "permanenter Fehler",
  "errore temporaneo": "temporaerer Fehler", "codice costruttore": "Herstellercode",
  "Creato": "Erstellt", "telegrammi": "Telegramme", "mesi": "Monate",
  "letture dal telegramma": "Staende aus Telegramm", "dalla piattaforma": "von Plattform",
  "da .rep WTT16": "aus WTT16 .rep", "senza valore": "ohne Wert",
  "Nessun telegramma nei file.": "Kein Telegramm in den Dateien.",
  "?  Guida": "?  Hilfe", "Cartelle": "Ordner", "Lingua": "Sprache",
  "Tabella letture Lobaro (finestra)": "Lobaro Ablesetabelle",
  "cambia...": "aendern...", "File scelti:": "Gewaehlte Dateien:",
  "ANTEPRIMA - Letture mensili (una riga per matricola; nell'Excel ci sono anche Consumi mensili, Valori memorizzati e Telegrammi)":
      "VORSCHAU - Monatsstaende (eine Zeile pro Zaehler; die Excel-Datei enthaelt auch Monatsverbrauch, Gespeicherte Werte und Telegramme)",
  "Pronto. Scegli il CSV esportato dalla piattaforma Lobaro.": "Bereit. Waehlen Sie die aus der Lobaro-Plattform exportierte CSV-Datei.",
  "PRENDO I CSV DA:": "CSV LESEN AUS:", "ARCHIVIO (Excel, PDF, copia dei CSV):": "ARCHIV (Excel, PDF, CSV-Kopien):",
  "Cartelle NON impostate: premi 'Cartelle' per dire dove prendere i CSV e dove archiviare il materiale.":
      "Ordner NICHT gesetzt: 'Ordner' druecken, um festzulegen, woher die CSV kommen und wohin archiviert wird.",
  "CARTELLE DI LAVORO": "ARBEITSORDNER", "PRIMO AVVIO: ": "ERSTER START: ",
  "Dimmi dove PRENDERE i CSV esportati dalla piattaforma Lobaro e dove ARCHIVIARE\ntutto il materiale (tabelle Excel, PDF di stampa e una copia dei CSV elaborati).\nLe due cartelle possono anche coincidere. Si cambiano quando vuoi, da qui.":
      "Bitte angeben, woher die aus der Lobaro-Plattform exportierten CSV-Dateien GELESEN werden und wohin\nalles ARCHIVIERT wird (Excel-Tabellen, Druck-PDFs und eine Kopie der verarbeiteten CSV-Dateien).\nBeide Ordner duerfen gleich sein. Sie koennen jederzeit hier geaendert werden.",
  "Prendo i CSV da (cartella dei download):": "CSV lesen aus (Download-Ordner):",
  "Archivio del materiale (Excel, PDF, CSV):": "Archiv (Excel, PDF, CSV):", "Sfoglia...": "Durchsuchen...",
  "Consiglio: l'archivio su una cartella di rete condivisa, cosi' lo vedono tutti.": "Tipp: Archiv auf einem freigegebenen Netzwerkordner, damit alle es sehen.",
  "Compila tutte e due le cartelle.": "Bitte beide Ordner ausfuellen.",
  "La cartella non esiste:\n%s\n\nLa creo?\n\n(INVIO = Si'   -   ESC = No)": "Der Ordner existiert nicht:\n%s\n\nAnlegen?\n\n(EINGABE = Ja   -   ESC = Nein)",
  "Non riesco a crearla: %s": "Kann nicht angelegt werden: %s", "Non riesco a salvare impostazioni.cfg: %s": "impostazioni.cfg kann nicht gespeichert werden: %s",
  "Cartelle salvate. Ora '1. Scegli i file...'": "Ordner gespeichert. Jetzt '1. Dateien waehlen...'",
  "Salva": "Speichern", "Annulla": "Abbrechen", "(nessuno)": "(keine)",
  "Scegli il CSV Lobaro o il file .rep/.BIL del gateway WTT16": "Lobaro-CSV oder .rep/.BIL-Datei des WTT16-Gateways waehlen",
  "CSV Lobaro / .rep WTT16": "Lobaro CSV / WTT16 .rep", "CSV Lobaro": "Lobaro CSV", "Tutti i file": "Alle Dateien",
  "questo programma legge solo i CSV della piattaforma Lobaro": "dieses Programm liest nur die CSV-Dateien der Lobaro-Plattform",
  "1. Scegli i file (CSV Lobaro)...": "1. Dateien waehlen (Lobaro CSV)...",
  "FILE DA ELABORARE\nCSV Lobaro": "ZU VERARBEITENDE DATEIEN\nLobaro CSV",
  "Scegli il CSV esportato dalla piattaforma Lobaro": "Die aus der Lobaro-Plattform exportierte CSV-Datei waehlen",
  "%d file scelti. Premi '2. Crea tabella Excel + PDF'.": "%d Dateien gewaehlt. '2. Excel + PDF-Tabelle erstellen' druecken.",
  "Elenco file svuotato.": "Dateiliste geleert.", "Tabella": "Tabelle",
  "Prima scegli almeno un CSV (pulsante 1).": "Zuerst mindestens eine Datei waehlen (Taste 1).",
  "Prima imposta le cartelle (pulsante 'Cartelle' in alto).": "Zuerst die Ordner setzen (Taste 'Ordner' oben).",
  "Esiste gia':\n%s\n\nLo sovrascrivo?\n\n(INVIO = Si'   -   ESC = No)": "Existiert bereits:\n%s\n\nUeberschreiben?\n\n(EINGABE = Ja   -   ESC = Nein)",
  "Leggo i telegrammi e preparo la tabella...": "Telegramme werden gelesen, Tabelle wird erstellt...",
  "ERRORE: %s": "FEHLER: %s", "(dettagli in errori.txt)": "(Details in errori.txt)",
  "Creati in archivio Excel e PDF: %s%s   (3 = Excel, 4 = PDF da stampare)": "Excel und PDF im Archiv erstellt: %s%s   (3 = Excel, 4 = PDF zum Drucken)",
  ", file copiati: %d": ", kopierte Dateien: %d",
  "Excel creato, anteprima non riuscita (vedi errori.txt)": "Excel erstellt, Vorschau fehlgeschlagen (siehe errori.txt)",
  "Chiudi": "Schliessen", "Guida - Tabella letture Lobaro": "Hilfe - Lobaro Ablesetabelle",
  "FILE DA ELABORARE\nCSV Lobaro o .rep WTT16": "ZU VERARBEITENDE DATEIEN\nLobaro CSV oder WTT16 .rep",
  "1. Scegli i file (CSV Lobaro / .rep WTT16)...": "1. Dateien waehlen (Lobaro CSV / WTT16 .rep)...",
  "Togli dall'elenco": "Liste leeren", "TABELLA\nExcel + PDF": "TABELLE\nExcel + PDF",
  "2. Crea tabella Excel + PDF": "2. Excel + PDF-Tabelle erstellen", "3. Apri l'Excel": "3. Excel oeffnen",
  "4. Apri il PDF (stampa)": "4. PDF oeffnen (Druck)", "Apri la cartella archivio": "Archivordner oeffnen",
  "Cambio lingua: la finestra si riapre.": "Sprachwechsel: das Fenster wird neu geoeffnet.",
 },
}

def imposta_lingua(l):
    global LINGUA
    LINGUA = l if l in LINGUE else "it"

def T(s):
    """traduzione del testo italiano s nella lingua attiva (s se manca)"""
    if not isinstance(s, str): return s
    return TESTI.get(LINGUA, {}).get(s, s)

def _tr(v):
    return T(v) if isinstance(v, str) else v

# ------------------------------------------------ ditta e logo (Lobaro)
_DIR = os.path.dirname(os.path.abspath(__file__))
# EDIZIONE (edizione.cfg accanto al programma; testo JSON con estensione anonima): ditta, loghi, lingue mostrate,
# formati letti e colore. Senza file valgono i valori Lobaro qui sotto.
EDIZIONE = {"ditta": "Lobaro", "logo_jpg": "logo_lobaro.jpg", "logo_png": "logo_lobaro_header.png",
            "lingue": ["it", "en", "de"], "formati": ["csv"], "colore": "0080B0",
            "guide": {"it": "GUIDA LobaroTabella.pdf", "en": "GUIDE LobaroTabella (EN).pdf",
                      "de": "ANLEITUNG LobaroTabella (DE).pdf"}}
try:
    import json as _json
    _pe = os.path.join(_DIR, "edizione.cfg")
    if not os.path.exists(_pe): _pe = os.path.join(_DIR, "edizione.json")   # vecchio nome
    with open(_pe, encoding="utf-8") as _f:
        _e = _json.load(_f)
    if isinstance(_e, dict): EDIZIONE.update(_e)
except Exception:
    pass
DITTA = EDIZIONE["ditta"]
LOGO_JPG = EDIZIONE["logo_jpg"]      # nei documenti (Excel e PDF)
LOGO_PNG = EDIZIONE["logo_png"]      # nella testata della finestra
FORMATI = [f.lower() for f in EDIZIONE.get("formati", ["csv"])]
LEGGE_REP = "rep" in FORMATI
COLORE_HEX = str(EDIZIONE.get("colore", "0080B0")).lstrip("#").upper()
COLORE_RGB = tuple(int(COLORE_HEX[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
FIRMA = "by BedoMaxContab"           # firma del produttore, sempre presente
LOGO_BMC = "logo_bmc_piccolo.jpg"

def logo_bmc_bytes():
    try:
        with open(os.path.join(_DIR, LOGO_BMC), "rb") as f: return f.read()
    except Exception:
        return None

def lingue_edizione():
    return [l for l in EDIZIONE.get("lingue", ["it"]) if l in LINGUE] or ["it"]

def filtro_file():
    """filetypes per le finestre di scelta file, secondo i formati dell'edizione"""
    if LEGGE_REP:
        return [(T("CSV Lobaro / .rep WTT16"), "*.csv *.rep *.BIL"), (T("Tutti i file"), "*.*")]
    return [(T("CSV Lobaro"), "*.csv"), (T("Tutti i file"), "*.*")]

def logo_jpeg_bytes():
    p = os.path.join(_DIR, LOGO_JPG)
    try:
        with open(p, "rb") as f: return f.read()
    except Exception:
        return None

def _jpeg_dim(dati):
    """(larghezza, altezza) di un JPEG dai marker SOF"""
    try:
        i = 2
        while i < len(dati):
            if dati[i] != 0xFF: return None
            m = dati[i + 1]; ln = (dati[i + 2] << 8) | dati[i + 3]
            if m in (0xC0, 0xC1, 0xC2):
                return ((dati[i + 7] << 8) | dati[i + 8], (dati[i + 5] << 8) | dati[i + 6])
            i += 2 + ln
    except Exception:
        pass
    return None

def _logo_fit(dati, max_w, max_h):
    d = _jpeg_dim(dati) or (3, 1)
    k = min(max_w / d[0], max_h / d[1])
    return d[0] * k, d[1] * k

RIGA_TESTA = 3     # riga delle intestazioni di colonna nei fogli (1-2 = titolo + logo)

def foglio_xml(intest, righe, larghezze, titolo, con_logo):
    """righe = liste di celle: None|str|int|float|datetime"""
    r0 = RIGA_TESTA
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
           'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
           '<sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane xSplit="1" ySplit="%d" topLeftCell="B%d" '
           'activePane="bottomRight" state="frozen"/></sheetView></sheetViews>' % (r0, r0 + 1),
           '<sheetFormatPr defaultRowHeight="13.5"/><cols>']
    for k, w in enumerate(larghezze, 1):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (k, k, w))
    out.append('</cols><sheetData>')
    def cella(ref, v, st=0):
        if v is None or v == "": return ""
        if isinstance(v, datetime):
            return '<c r="%s" s="%d"><v>%s</v></c>' % (ref, 2 if v.hour or v.minute else 1, repr(_excel_dt(v)))
        if isinstance(v, bool): v = "SI" if v else "NO"
        if isinstance(v, (int, float)):
            return '<c r="%s" s="%d"><v>%s</v></c>' % (ref, st, repr(v) if isinstance(v, float) else v)
        return '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, _esc(v))
    # riga 1: titolo (a destra del logo), riga 2: sottotitolo
    out.append('<row r="1" ht="24" customHeight="1">' + cella("D1", titolo, 4) + '</row>')
    out.append('<row r="2" ht="18" customHeight="1">' + cella("D2", "%s - %s %s   -   %s"
               % (DITTA, T("tabella letture Lobaro - generata il"), datetime.now().strftime("%d/%m/%Y %H:%M"), FIRMA), 5) + '</row>')
    out.append('<row r="%d" ht="33" customHeight="1">' % r0 + "".join(cella("%s%d" % (_col(k), r0), h, 3) for k, h in enumerate(intest, 1)) + '</row>')
    for i, r in enumerate(righe, r0 + 1):
        out.append('<row r="%d">' % i + "".join(cella("%s%d" % (_col(k), i), v) for k, v in enumerate(r, 1)) + '</row>')
    out.append('</sheetData><autoFilter ref="A%d:%s%d"/>' % (r0, _col(len(intest)), max(r0, len(righe) + r0)))
    out.append('<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
               '<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/>')
    if con_logo:
        out.append('<drawing r:id="rId1"/>')
    out.append('</worksheet>')
    return "".join(out)

def _drawing_xml(w_px, h_px):
    """logo ancorato in A1 (oneCellAnchor), misure in EMU"""
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            '<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>38100</xdr:colOff>'
            '<xdr:row>0</xdr:row><xdr:rowOff>19050</xdr:rowOff></xdr:from>'
            '<xdr:ext cx="%d" cy="%d"/>'
            '<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Logo"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr>'
            '<xdr:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId1"/>'
            '<a:stretch><a:fillRect/></a:stretch></xdr:blipFill>'
            '<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic>'
            '<xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>'
            % (w_px * 9525, h_px * 9525, w_px * 9525, h_px * 9525))

def scrivi_xlsx(path, fogli):
    """fogli = [(nome, intest, righe, larghezze), ...]. Logo della ditta in
    ogni foglio (righe 1-2), intestazioni alla riga 3."""
    logo = logo_jpeg_bytes()
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
          '<Default Extension="xml" ContentType="application/xml"/>',
          '<Default Extension="jpeg" ContentType="image/jpeg"/>',
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    for k in range(1, len(fogli) + 1):
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % k)
        if logo:
            ct.append('<Override PartName="/xl/drawings/drawing%d.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' % k)
    ct.append('</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '</Relationships>')
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
    wrels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
             '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for k, (nome, _, _, _) in enumerate(fogli, 1):
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_esc(nome[:31]), k, k))
        wrels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (k, k))
    wb.append('</sheets></workbook>')
    wrels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' % (len(fogli) + 1))
    wrels.append('</Relationships>')
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
              '<numFmts count="2"><numFmt numFmtId="164" formatCode="dd/mm/yyyy"/>'
              '<numFmt numFmtId="165" formatCode="dd/mm/yyyy hh:mm"/></numFmts>'
              '<fonts count="4"><font><sz val="10"/><name val="Calibri"/></font>'
              '<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
              '<font><b/><sz val="14"/><color rgb="FF%s"/><name val="Calibri"/></font>' % COLORE_HEX +
              '<font><i/><sz val="9"/><color rgb="FF7F8C8D"/><name val="Calibri"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill>'
              '<fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FF%s"/><bgColor indexed="64"/></patternFill></fill></fills>' % COLORE_HEX +
              '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
              '<border><left style="thin"><color rgb="FFD5D8DC"/></left><right style="thin"><color rgb="FFD5D8DC"/></right>'
              '<top style="thin"><color rgb="FFD5D8DC"/></top><bottom style="thin"><color rgb="FFD5D8DC"/></bottom><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="6">'
              '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>'
              '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>'
              '<xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>'
              '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
              '<alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
              '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
              '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
              '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
              '</styleSheet>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", "".join(ct))
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", "".join(wb))
        z.writestr("xl/_rels/workbook.xml.rels", "".join(wrels))
        z.writestr("xl/styles.xml", styles)
        if logo:
            z.writestr("xl/media/image1.jpeg", logo)
            w_px, h_px = _logo_fit(logo, 150, 50)
        for k, (nome, intest, righe, larg) in enumerate(fogli, 1):
            z.writestr("xl/worksheets/sheet%d.xml" % k, foglio_xml(intest, righe, larg, nome, bool(logo)))
            if logo:
                z.writestr("xl/worksheets/_rels/sheet%d.xml.rels" % k,
                           '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                           '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                           '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing%d.xml"/>'
                           '</Relationships>' % k)
                z.writestr("xl/drawings/drawing%d.xml" % k, _drawing_xml(int(w_px), int(h_px)))
                z.writestr("xl/drawings/_rels/drawing%d.xml.rels" % k,
                           '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                           '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                           '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.jpeg"/>'
                           '</Relationships>')

# ---------------------------------------------------------- stampa PDF
class _Pdf:
    """Scrittore PDF minimo: Helvetica, testo WinAnsi, righe, rettangoli,
    immagini JPEG (DCTDecode). Pagina A4 orizzontale."""
    W, H = 841.89, 595.28
    def __init__(self):
        self.pagine = []; self.cur = []; self.img = None; self.imgs = {}
    def nuova(self):
        if self.cur: self.pagine.append(self.cur)
        self.cur = []
    def _t(self, s):
        s = str(s).encode("cp1252", "replace").decode("cp1252")
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    def testo(self, x, y, s, size=8, bold=False, col=(0, 0, 0)):
        self.cur.append("BT /F%d %.1f Tf %.3f %.3f %.3f rg %.2f %.2f Td (%s) Tj ET"
                        % (2 if bold else 1, size, col[0], col[1], col[2], x, self.H - y, self._t(s)))
    def testo_d(self, x_dx, y, s, size=8, bold=False, col=(0, 0, 0)):
        self.testo(x_dx - self.larg(s, size), y, s, size, bold, col)
    def larg(self, s, size):
        return len(str(s)) * size * 0.52
    def rett(self, x, y, w, h, fill):
        self.cur.append("%.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f" % (fill[0], fill[1], fill[2], x, self.H - y - h, w, h))
    def linea(self, x1, y1, x2, y2, col=(0.8, 0.8, 0.8), sp=0.5):
        self.cur.append("%.3f %.3f %.3f RG %.2f w %.2f %.2f m %.2f %.2f l S" % (col[0], col[1], col[2], sp, x1, self.H - y1, x2, self.H - y2))
    def immagine(self, dati, x, y, w, h):
        """immagine JPEG; piu' immagini diverse = piu' XObject (Im1, Im2...)"""
        k = None
        for nome, d in self.imgs.items():
            if d is dati or d == dati: k = nome; break
        if k is None:
            k = "Im%d" % (len(self.imgs) + 1); self.imgs[k] = dati
        self.img = dati
        self.cur.append("q %.2f 0 0 %.2f %.2f %.2f cm /%s Do Q" % (w, h, x, self.H - y - h, k))
    def salva(self, path):
        if self.cur: self.pagine.append(self.cur); self.cur = []
        objs = []
        def add(s):
            objs.append(s); return len(objs)
        f1 = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        f2 = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        ims = {}
        for nome, dati in self.imgs.items():
            d = _jpeg_dim(dati) or (1, 1)
            ims[nome] = add(("<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceRGB "
                             "/BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n" % (d[0], d[1], len(dati)),
                             dati))
        pag_ids = []
        pages_id = len(objs) + 1 + 2 * len(self.pagine)
        for pg in self.pagine:
            cont = "\n".join(pg).encode("latin-1", "replace")
            c = add(("<< /Length %d >>\nstream\n" % len(cont), cont))
            res = "/Font << /F1 %d 0 R /F2 %d 0 R >>" % (f1, f2) + \
                  (" /XObject << %s >>" % " ".join("/%s %d 0 R" % (n, i) for n, i in ims.items()) if ims else "")
            pag_ids.append(add("<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] /Contents %d 0 R /Resources << %s >> >>"
                               % (pages_id, self.W, self.H, c, res)))
        pid = add("<< /Type /Pages /Kids [%s] /Count %d >>" % (" ".join("%d 0 R" % i for i in pag_ids), len(pag_ids)))
        assert pid == pages_id
        cat = add("<< /Type /Catalog /Pages %d 0 R >>" % pid)
        out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"); offs = []
        for i, o in enumerate(objs, 1):
            offs.append(len(out)); out += ("%d 0 obj\n" % i).encode()
            if isinstance(o, tuple):
                out += o[0].encode("latin-1"); out += o[1]; out += b"\nendstream"
            else:
                out += o.encode("latin-1")
            out += b"\nendobj\n"
        x = len(out)
        out += ("xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)).encode()
        for o in offs: out += ("%010d 00000 n \n" % o).encode()
        out += ("trailer\n<< /Size %d /Root %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, cat, x)).encode()
        with open(path, "wb") as f: f.write(bytes(out))

def firma_pdf(pdf, x_centro, y, bmc=None, size=6.5):
    """'by BedoMaxContab' in piccolo, con il logo BMC se c'e' (piede delle stampe)"""
    GRI = (0.55, 0.55, 0.55)
    w_t = pdf.larg(FIRMA, size)
    if bmc:
        w, h = _logo_fit(bmc, 40, 11)
        x0 = x_centro - (w + 4 + w_t) / 2.0
        pdf.immagine(bmc, x0, y - h + 1, w, h)
        pdf.testo(x0 + w + 4, y, FIRMA, size, False, GRI)
    else:
        pdf.testo(x_centro - w_t / 2.0, y, FIRMA, size, False, GRI)

def stampa_pdf(righe, mesi, out_pdf, titolo=None, chiave="_letture"):
    """Tabulato PDF (A4 orizzontale) con logo della ditta: una riga per
    matricola, colonne fisse + una per mese; se i mesi non entrano in una
    pagina, le colonne dei mesi proseguono su un secondo blocco di pagine."""
    VERDE, GRI = COLORE_RGB, (0.45, 0.45, 0.45)              # colore dell'edizione
    CHIARO = tuple(1 - (1 - c) * 0.12 for c in COLORE_RGB)    # righe alternate
    bmc = logo_bmc_bytes()
    titolo = titolo or T("Letture mensili")
    pdf = _Pdf(); logo = logo_jpeg_bytes()
    fisse = [("Matricola (pdf)", 56, "Matricola", "s"), ("Tipo", 48, "Tipo", "s"), ("Costrut-|tore", 40, "Costruttore", "s"),
             ("Ultimo|scarico", 72, "Ultimo scarico", "dt"), ("Ultima|lettura", 52, "Ultima lettura", "n"),
             ("Unita'", 34, "Unita'", "s"), ("Valore al|set-day", 52, "Valore al set-day", "n"),
             ("Data|set-day", 54, "Data set-day", "d"), ("N. tele-|grammi", 40, "N. telegrammi", "n"),
             ("Batt.", 34, "Batteria", "s"), ("Err.", 24, "Errore (cod.)", "n")]
    X0, X1, Y0 = 28, pdf.W - 28, 104
    w_fisse = sum(w for _, w, _, _ in fisse); w_mese = 44
    per_pag = max(1, int((X1 - X0 - w_fisse) // w_mese))
    blocchi = [mesi[i:i + per_pag] for i in range(0, len(mesi), per_pag)] or [[]]
    def fmt(v, t):
        if v is None: return ""
        if t == "dt": return v.strftime("%d/%m/%y %H:%M")
        if t == "d": return v.strftime("%d/%m/%Y")
        if t == "n":
            if isinstance(v, float): return ("%.3f" % v).rstrip("0").rstrip(".") if v != int(v) else str(int(v))
            return str(v)
        return str(v)
    npag = [0]
    def testata(blocco, k):
        pdf.nuova(); npag[0] += 1
        if logo:
            w, h = _logo_fit(logo, 120, 40); pdf.immagine(logo, X0, 22, w, h)
        pdf.testo_d(X1, 34, "%s - %s" % (DITTA, titolo), 13, True, VERDE)
        pdf.testo_d(X1, 48, "%s  -  %s %s  -  %s %s %s %s%s"
                    % (T("Tabella letture Lobaro"), T("generata il"), datetime.now().strftime("%d/%m/%Y %H:%M"),
                       T("mesi da"), etichetta_mese(blocco[0]) if blocco else "-", T("a"),
                       etichetta_mese(blocco[-1]) if blocco else "-",
                       "  (%s %d)" % (T("blocco"), k + 1) if len(blocchi) > 1 else ""),
                    8, False, GRI)
        pdf.linea(X0, 70, X1, 70, VERDE, 1.2)
        y = Y0 - 14                       # intestazione su DUE righe (testo a capo)
        pdf.rett(X0, y - 19, X1 - X0, 23, VERDE)
        x = X0
        for et, w, _, _ in fisse:
            parti = T(et).split("|")
            for j, pt in enumerate(parti):
                pdf.testo(x + 2, y - 9 * (len(parti) - 1 - j), pt, 7.2, True, (1, 1, 1))
            x += w
        for m in blocco:
            pdf.testo_d(x + w_mese - 2, y, etichetta_mese(m), 7.2, True, (1, 1, 1)); x += w_mese
        return Y0
    def piede():
        pdf.testo_d(X1, pdf.H - 16, "%s %d" % (T("pag."), npag[0]), 7, False, GRI)
        pdf.testo(X0, pdf.H - 16, "%s  -  %s  -  %d %s" % (DITTA, titolo, len(righe), T("matricole")), 7, False, GRI)
        firma_pdf(pdf, (X0 + X1) / 2.0, pdf.H - 16, bmc)
    for k, blocco in enumerate(blocchi):
        y = testata(blocco, k)
        for i, r in enumerate(righe):
            if y > pdf.H - 40:
                piede()
                y = testata(blocco, k)
            if i % 2 == 0: pdf.rett(X0, y - 9, X1 - X0, 12, CHIARO)
            x = X0
            for _, w, campo, t in fisse:
                s = fmt(_tr(r.get(campo)), t)
                if t == "n": pdf.testo_d(x + w - 2, y, s, 7.2)
                else: pdf.testo(x + 2, y, s[:int(w / 3.6)], 7.2)
                x += w
            for m in blocco:
                pdf.testo_d(x + w_mese - 2, y, fmt(r[chiave].get(m), "n"), 7.2); x += w_mese
            y += 12
        piede()
    pdf.salva(out_pdf)
    return out_pdf

# ---------------------------------------------------------------- main
def etichetta_mese(mm):
    MESI = _MESI.get(LINGUA, _MESI["it"])
    y, m = mm.split("-")
    return "%s %s" % (MESI[int(m) - 1], y)

def crea_tabella(csv_paths, out_path=None):
    tel, visti = [], set()
    for p in csv_paths:
        for t in leggi_file(p):         # piu' file uniti: stesso telegramma una volta sola
            k = (t["matricola"], t["dt"], t["main"], t["rssi"])
            if k in visti: continue
            visti.add(k); tel.append(t)
    if not tel:
        raise ValueError(T("Nessun telegramma nei file."))
    righe, mesi = elabora(tel)
    testa = ["Matricola", "Tipo", "Costruttore", "Primo ascolto", "Ultimo scarico",
             "Ultima lettura", "Unita'", "Data lettura (orologio app.)", "Valore al set-day",
             "Data set-day", "RSSI ultimo", "N. telegrammi", "Fonte", "Batteria", "Errore (cod.)",
             "Significato errore"]
    larg = [12, 12, 12, 17, 17, 12, 9, 17, 13, 13, 9, 11, 13, 10, 9, 28] + [11] * len(mesi)
    et = [etichetta_mese(m) for m in mesi]
    f1 = [[_tr(r[k]) for k in testa] + [r["_letture"].get(m) for m in mesi] for r in righe]
    f2 = [[_tr(r[k]) for k in testa] + [r["_consumi"].get(m) for m in mesi] for r in righe]
    t3 = ["Matricola", "Ricevuto (wM-Bus)", "Scaricato dalla piattaforma", "Tipo", "Costruttore",
          "Versione", "CI", "Lettura", "Unita'", "Valore al set-day", "Data set-day",
          "Orologio apparecchio", "RSSI", "Fonte", "Batteria", "Errore (cod.)", "Significato errore",
          "Main Value piattaforma", "File"]
    f3 = [[t["matricola"], t["dt"], t["ricevuto"], t["tipo"], t["mf"], t["ver"], t["ci"],
           t["valore"], T(t["unita"]), t["set_valore"], t["set_data"], t["orologio"], t["rssi"],
           T(t["fonte"]), T(t.get("batteria")), t.get("errore"),
           descrivi_stato(t.get("errore"), siemens=(t["fonte"] == "rep" or (t.get("mf") or "").upper() == "LSE")),
           t["main"], t["file"]]
          for t in sorted(tel, key=lambda x: (x["matricola"], x["dt"]))]
    # valori memorizzati dagli apparecchi (fine mese, set-day): uno per data
    memo = {}
    for t in tel:
        for d, v in t["storici"]:
            k = (t["matricola"], d)
            if k not in memo or t["dt"] > memo[k][2]:
                memo[k] = (v, t["unita"], t["dt"])
    f4 = [[m, d, v, T(u), dt] for (m, d), (v, u, dt) in sorted(memo.items())]
    t4 = ["Matricola", "Data memorizzata", "Valore", "Unita'", "Da telegramma del"]
    if not out_path:
        base = os.path.splitext(csv_paths[0])[0]
        out_path = base + " - tabella.xlsx"
    testa_t = [T(k) for k in testa]
    scrivi_xlsx(out_path, [
        (T("Letture mensili"), testa_t + et, f1, larg),
        (T("Consumi mensili"), testa_t + et, f2, larg),
        (T("Valori memorizzati"), [T(k) for k in t4], f4, [12, 17, 12, 9, 17]),
        (T("Telegrammi"), [T(k) for k in t3], f3, [12, 17, 17, 12, 12, 9, 7, 12, 9, 13, 13, 17, 7, 12, 9, 9, 28, 22, 30]),
    ])
    out_pdf = os.path.splitext(out_path)[0] + ".pdf"
    try:
        stampa_pdf(righe, mesi, out_pdf)
    except PermissionError:
        out_pdf = None                       # PDF aperto nel lettore: si salta
    n_dec = sum(1 for t in tel if t["fonte"] == "telegramma")
    n_bmp = sum(1 for t in tel if t["fonte"] == "BMP")
    n_pf = sum(1 for t in tel if t["fonte"] == "piattaforma")
    n_rep = sum(1 for t in tel if t["fonte"] == "rep")
    n_no = sum(1 for t in tel if t["fonte"] == "-")
    riass = ("%s: %s (+ PDF)\n%d %s, %d %s, %d %s (%s .. %s)\n"
             "%s: %d, BMP: %d, %s: %d, %s: %d, %s: %d"
             % (T("Creato"), out_path, len(tel), T("telegrammi"), len(righe), T("matricole"), len(mesi), T("mesi"),
                et[0] if et else "-", et[-1] if et else "-",
                T("letture dal telegramma"), n_dec, n_bmp, T("dalla piattaforma"), n_pf, T("da .rep WTT16"), n_rep,
                T("senza valore"), n_no))
    return out_path, riass, righe, mesi

def main(argv):
    files = [a for a in argv if a.lower().endswith((".csv", ".txt", ".rep", ".bil"))]
    gui = False
    if not files:
        try:
            import tkinter as tk
            from tkinter import filedialog, messagebox
            root = tk.Tk(); root.withdraw(); gui = True
            files = list(filedialog.askopenfilenames(
                title="Scegli il CSV esportato dalla piattaforma Lobaro",
                filetypes=filtro_file()))
            if not files:
                return 0
        except Exception:
            print(__doc__); return 1
    else:
        messagebox = None
    try:
        out, riass = crea_tabella(files)[:2]
        print(riass)
        if gui:
            messagebox.showinfo("LobaroTabella", riass)
        return 0
    except Exception as e:
        msg = "ERRORE: %s" % e
        print(msg); traceback.print_exc()
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "LobaroTabella - errori.txt"), "a", encoding="utf-8") as f:
                f.write("%s\n%s\n%s\n" % (datetime.now(), msg, traceback.format_exc()))
        except Exception:
            pass
        if gui:
            messagebox.showerror("LobaroTabella", msg)
        return 1

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
