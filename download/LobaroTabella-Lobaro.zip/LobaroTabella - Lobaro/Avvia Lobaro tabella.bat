@echo off
rem Avvia la finestra "Tabella letture Lobaro" (stile BedoMaxContab).
rem Trascinando uno o piu' CSV su questo file risultano gia' scelti.
rem Percorsi completi: cd /d fallisce con le cartelle aperte via \\server.
title Lobaro tabella
set "PYEXE="
where pythonw >nul 2>nul && set "PYEXE=pythonw"
if not defined PYEXE where pyw >nul 2>nul && set "PYEXE=pyw -3"
if not defined PYEXE (
  echo Python 3 non trovato: installarlo da python.org con la spunta "Add python.exe to PATH".
  pause
  exit /b 1
)
start "" %PYEXE% "%~dp0LobaroTabella.pyw" %*
exit /b 0
