LOBAROTABELLA - Lobaro edition
==================================
Readings table from the Lobaro platform CSV export: one row per meter, the
download dates, the reading of every month (most recent first), battery and
error codes. Excel file with 4 sheets + PDF to print, with the Lobaro logo.

INSTALLATION (once)
 1. Install Python 3 from python.org (free) ticking "Add python.exe to PATH".
 2. Copy this folder anywhere (network share or USB stick are fine).
 3. Double-click "Avvia Lobaro tabella.bat". At the first start the program asks
    for the two working folders (where to read the files, where to archive).

Language: drop-down at the top of the window (Italiano / English / Deutsch).
Everything else is in the guides: GUIDA LobaroTabella.pdf, GUIDE LobaroTabella (EN).pdf, ANLEITUNG LobaroTabella (DE).pdf (also from the "? Help" button).

by BedoMaxContab - (c) 2026 BedoMaxContab - all rights reserved.
